
<!-- README.md is generated from README.Rmd. Please edit that file -->
bloodstats
==========

A package with utilities for basic statistics on blood biomarkers.

Installation
------------

``` r
# # Install devtools if you don't have it already
# install.packages("devtools")
devtools::install_github("johndoe/bloodstats")
```

Examples
--------

``` r
data.frame(er = c(1, 2, 3), c(4, 5, 6)) %>%
  bloodstats::bloodmeans()
```
