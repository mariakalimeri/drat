library(testthat)
library(bloodstats)

test_check("bloodstats")
